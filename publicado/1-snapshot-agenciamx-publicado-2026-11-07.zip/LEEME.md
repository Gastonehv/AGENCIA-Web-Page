# Respaldo de agenciamx.app (versión publicada en vivo)

## Qué es esto

Copia exacta, archivo por archivo, de lo que sirve **https://agenciamx.app/** (Netlify)
descargada por HTTPS el **7 de noviembre de 2026, ~10:26 CST**.

Son **33 archivos**. La lista completa con sus hashes SHA-256 está en `SHA256SUMS.txt`.

## Dónde vive este respaldo y por qué aquí

- Repo: `Gastonehv/AGENCIA-Web-Page`, rama **`respaldo-publicado-2026-11-07`**, carpeta `publicado/`.
- La **fuente vieja** (9 de octubre de 2026) está en la rama `main` de este mismo repo, y hay
  otra versión en la rama `version-publicada-2026-10-26`. Ninguna de las dos es idéntica a lo
  que está en vivo hoy; por eso este respaldo va aparte, en su propia rama.
- **Esta rama no publica nada**: en Netlify el proyecto "agenciamx" despliega únicamente la
  rama `main` (verificado el 2026-11-07 en la configuración del sitio; los deploys de ramas
  están desactivados). Subir cosas a esta rama es seguro; **subir a `main` sí reemplazaría el
  sitio en vivo con el código viejo — no hacerlo**.

## Cuál es cuál (resumen)

| Contenido | Ubicación |
|---|---|
| Versión EN VIVO al 2026-11-07 (este respaldo) | rama `respaldo-publicado-2026-11-07`, carpeta `publicado/` |
| Fuente vieja (2026-10-09) | rama `main` (¡es la rama de producción de Netlify!) |
| Versión anterior publicada | rama `version-publicada-2026-10-26` |

## Notas

- El sitio en vivo sirve las páginas HTML junto con sus `.md` (`index.md`, `acerca.md`,
  `contacto.md`, `privacidad.md`, `terminos.md`, `404.md`); ambos formatos están incluidos.
- `/agentes-ia-xalapa/` aparece en el sitemap pero **responde 404 en vivo** (sitemap
  desactualizado); no hay archivo que respaldar de esa ruta.
- El sitio usa una **función edge compilada de Netlify cuya fuente no está en el repo**
  (según el manual de contexto de Hark). Es un componente externo: vive desplegada en
  Netlify, no en GitHub.
- No hay claves ni datos privados en este respaldo: es una web pública de marketing.

## Cómo verificar

Descargar cualquier archivo del sitio en vivo y comparar con el hash de `SHA256SUMS.txt`:

```
curl -s https://agenciamx.app/index.html | shasum -a 256
# debe dar: c1a9299e413bf5e91120873024db4401e5382302b630280274188c76d3ce3405
```

Todos los archivos de esta carpeta se verificaron byte a byte (SHA-256) contra el sitio en
vivo al momento de subirlos.
